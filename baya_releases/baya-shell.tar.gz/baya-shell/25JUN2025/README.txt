                        Baya - SoC Integration Tool
                        ===========================

About 
    This is a RTL hookup tool which can import VHDL and Verilog RTLs
( on the ports and generics/parameters ) and IPXACT component and 
then instantiate those at the top level ( SoC or SubSystem level ). 
User needs to specify the intended connections and the tool will
make the connections at the top level.

Howto run examples ?

    Go ( cd ) to the installation directory i.e the directory where this README
    file resides. Execute the commands- 

        ====================================
        source setup_env.csh or setup_env.sh
        cd examples
        ls
        cd <example-dir>
        ./runme.csh    
        ====================================
        Alternatively for Unix

        setenv EDAUTILS_ROOT /usr/user1/tools/baya-shell/01MAY2014
        set path = ( $EDAUTILS_ROOT/bin $path )

        and for Windows

        set EDAUTILS_ROOT=D:\tmp\baya-shell\01MAY2014
        set PATH="%path%;%EDAUTILS_ROOT%\bin"
        ====================================
    
    Like this you can run the other examples.

Commands
========

[1] Command : baya_get_current_module 

    Description: returns the currently active design.
               
[2] Command : baya_get_file 

    Description: returns the file name where the database needs to be saved
               
[3] Command : baya_get_line 

    Description: returns the line number to be saved for the construct(s)
                 to be created by the next set of Baya command(s)
               
[4] Command : baya_get_root 

    Description:  returns the root of the design database
               
[5] Command : baya_set_current_design 

    Description: sets the specified module as the currently active module.
    Options    : 
                 -name <module name> , mandatory option to specify the module name. 
    Example    : baya_set_current_design -name foo 
                
[6] Command : baya_set_current_module 

    Description: sets the specified module as the currently active module.
    Options    : 
                 -name <module name> , mandatory option to specify the module name. 
    Example    : baya_set_current_module -name foo 
                
[7] Command : baya_set_file 

    Description: Sets the name of the file where the design database will be saved. 
    Options    :  
                 -name <file name> , mandatory option to specify the module name.
    Example    : baya_set_file -name foo.v
                
[8] Command : baya_set_line 

    Description: Sets the number for the objects to be created in the following commands.
                 This command is mostly useful to debug the in memory design database ...
    Options    : 
                 -num <Line number> , mandatory option to specify the line number.
    Example    : baya_set_line -num 10
                
[9] Command : baya_add_timescale 

    Description: Adds `timescale directive in the generated RTL 
    Options    : 
                 -delay <reference> , mandatory input to specify the reference time value e.g. 1ns . 
                 -precision <value> , mandatory input to specify the precison value e.g. 10ps . 
    Example    : baya_add_timescale -delay 1ns -precision 10ps 
                
[10] Command : baya_add_define_directive 

    Description: Adds `define directive in the generated RTL 
    Options    : 
                 -var <name> , mandatory input to specify the name of the identifier/variable to be defined 
                 -value <value> , optional input to set value to the given macro
    Example    : baya_add_define_directive -var DATASIZE -value 16 
                
[11] Command : baya_add_include_file 

    Description: Adds `include directive in the generated RTL 
    Options    : 
                 -name < file name> , mandatory input to specify the name of the file to be included
                 -module <module name> , optional input, name of the module where this file
                                         is to be included. If not specified then the file will 
                                         get included in the current module.
                 -contains_params , optional boolean switch to specify that the specified file contains parameter declaration.
                                    If this switch is specified then this file will get included just before the port declaration.
    Example    : baya_add_include_file -name top.h -contains_params

                
[12] Command : baya_add_import 

    Description: Associates import statement with the current module
    Options    : 
                 -symbol < symbol > , mandatory input to specify the symbols to be imported. There should NOT be any space in the symbolname or star and package name
    Example    : baya_add_import -symbol mypack::mystruct 
                 baya_add_import -symbol mypack::* 

                
[13] Command : baya_exclude_auto_connections 

    Description: Excludes specified connections while making the automatic connections.

                 This command must be called before calling the command baya_auto_connect .
                 
    Options    : -connections <port1,port2,port3(inst1:inst2)>, mandatory switch 
                                           to enlist the ports which should NOT be connected automatically
                                           You can disable auto connection between any two instances by giving value
                                           as A(inst1:inst2) where the A is the common port between the instances inst1 and inst2.
                                           The port1, port2 are the top ports i.e. if you want
                                            to disable auto connections of the top port1 and port2.
                                            No space is allowed before and after the colon and the comma.
                                            You can call this command multiple times with different
                                            connection to avoid long line.

                      
    Example    : baya_exclude_auto_connection -connections port1(inst1:inst2),port2(inst1,inst5)

                
[14] Command : baya_auto_connect 

    Description: Establishes automatic connection between all the ports/pins 
                 of the given comma separated instances where the port/pin
                 names matches. No space is allowed before and after comma.
    Options    : 
                 -insts <instance names> , mandatory option to specify the instances
                                           between which the connection needs to be established.
                                           The instance names must be separated with comma(,) 
                 -exclude <port1,port2,port3(inst1:inst2)> ,  optional( use only if you need ) switch 
                                           to enlist the ports which should NOT be connected automatically
                                           You can disable connection between any two instances by specifying
                                           that as A(inst1:inst2) where it will NOT connect the inst1.A with inst2.A 
                                           where the A is the common port name and inst1 and inst2 are the instance names.
                                           No space is allowed before and after the colon and the comma.
                 -align_msb , optional boolean switch to align the connections with MSB of the 
                              bigger port(s) in case of port width mismatches.
                              Default is LSB aligned.
                    
                 -pad < 0 or 1> , optional( use only if you need ) switch 
                                  to specify the the high/low value with which the
                                  the extra bits of the mismatching input ports 
                                  needs to ve driven. Useful to handle port with mismatches.
                 -comment <"Inline comments to be printed"> , Provide comments in quotes
                                            which will get printed next to this port mapping.
                                            This option must be used as the last option of this command.
    Example    : baya_auto_connect -insts u_Inst1,u_Inst2 
                 baya_auto_connect -insts u_Inst1,u_Inst2 -pad 1
                 baya_auto_connect -insts u_Inst1,u_Inst2,u_Inst3 -pad 0 -exclude portA,portB
                 baya_auto_connect -insts u_A,u_B,u_C,u_D -exclude portA,port_B(u_D:u_C),port_C(u_B:u_C)
                 baya_auto_connect -insts u_Inst1,u_Inst2,u_Inst3 -align_msb
                
[15] Command : baya_connect_interfaces 

    Description: Creates connection between two interfaces specified with -from and the -two switches.

    Options    : 
                 -from <u_inst1.intf1>, mandatory option to specify the first interface often the one of type Master which drives.
                 -to <u_inst2.intf2>, mandatory option to specify the second interface often the one of type Slave which gets driven.
                 -intf_port_maps <formal1@actual1/formal2@actual2>, optional input for the port maps of the interface which will
                                                                    connect the two instances' interfaces
                 -intf_param_maps <param1=value/param2=value>, optional input for the parameter maps for the interface which will
                                                               connect the two instances' interfaces
                 -exclude <port1:port2> , optional( use only if you need ) switch 
                                          to enlist the logical ports which should be ignored while connecting the interfaces
                 -align_msb , optional boolean switch to align the connections with MSB of the 
                              bigger port(s) in case of port width mismatches.
                              Default is LSB aligned.
                    
                 -pad < 0 or 1> , optional( use only if you need ) switch 
                                  to specify the the high/low value with which the
                                  the extra bits of the mismatching input ports 
                                  needs to ve driven. Useful to handle port with mismatches.
                 -ifdef_var <macro name> , optional input, to specify the macro enclosing this interface map
                 -comment <"Inline comments to be printed"> , Provide comments in quotes which will
                                 get printed next to this port mapping. This option must be used
                                 as the last option of this command.

    Example    : baya_connect_interfaces -from u_Inst1.master_intf -to u_Inst2.slave_intf -intf_port_maps clk@gclk/reset@grst -intf_param_maps AWIDTH=64/DWIDTH=32
                 baya_connect_interfaces -from u_Inst1.master_intf -to u_Inst2.slave_intf -pad 1'b1
                 baya_connect_interfaces -from u_Inst1.master_intf -to u_Inst2.slave_intf -pad 1'b0 -exclude portA:portB
                 baya_connect_interfaces -from u_Inst1.master_intf -to u_Inst2.slave_intf -align_msb

                
[16] Command : baya_connect_ipxact_interfaces_by_converting_into_sv_interface 

    Description: Creates connection between two IP-XACT interfaces specified
                 with -from and the -two switches by converting the IP-XACT
                 interfaces into SV interfaces and instantiating the same in
                 the current design.

    Options    : 
                 -from <u_inst1.intf1>, mandatory option to specify the first interface often the one of type Master which drives.
                 -to <u_inst2.intf2>, mandatory option to specify the second interface often the one of type Slave which gets driven.
                 -exclude <port1:port2> , optional( use only if you need ) switch 
                                          to enlist the logical ports which should be ignored while connecting the interfaces
                 -v2014 , optional boolean switch to specify that the input IP-XACT version is 2014
                 -comment <"Inline comments to be printed"> , Provide comments in quotes
                                            which will get printed next to this port mapping.
                                            This option must be used as the last option of this command.

    Example    : baya_connect_ipxact_interfaces_by_converting_into_sv_interface -from u_Inst1.master_intf -to u_Inst2.slave_intf 

                
[17] Command : baya_exclude_auto_ports 

    Description: Excludes creation of the auto ports in the top module
                 corresponding to the given module's port. This command
                 is useful only when you want to create auto ports in the
                 top module through the command baya_create_auto_ports .

                 This command must be called before calling the command baya_create_auto_ports .
                 
    Options    : -ports <port1:port2>, optional switch to specify the ports to be ignored while creating the auto ports.
                                      You can also pass regular expression as port name, in such case
                                      all the ports matching with that pattern will get excluded from
                                      the auto creation.  Note that the char '.' is necessary before the '*' .
                                      In absence of this option, all the ports of the given module will
                                      get ignored while creating the auto ports at the top level.
                 -module < sub-module name> , mandatory input, to specify the name of the module whose
                                      ports to be excluded for auto creation in the top module
    Example    : baya_exclude_auto_ports -module leaf -ports port1:port2
                 baya_exclude_auto_ports -module submod -ports .*
                 baya_exclude_auto_ports -module bottom

                
[18] Command : baya_create_auto_ports 

    Description: Declares/Creates ports in the top module for the component
                 ports which are not connected while instantiation. This auto
                 created port is then mapped with the instance port/pin to
                 establish connection. This command gets effective while
                 elaborating the design and hence you must elaborate the design
                 after setting this command before printing or referring.

    Options    : -exclude <comp1(port1:port2),comp2(port2):comp3(test.*)> , optional switch to specify the ports 
                                 to be ignored while creating the auto ports at the top level.
                                 You can also pass regular expression as port name, in such case
                                 all the ports matching with the given pattern of that instance
                                 will get excluded from the auto creation. 
                                 Pass .* to exclude all the ports of a given component.

                                 If you want to exclude multiple ports/pins the you can
                                 use the comand baya_exclude_auto_ports before call this command.
    Example    : baya_create_auto_ports -exclude comp1(port1:port2),comp2(.*)

                
[19] Command : baya_set_top_module_auto_port_prefix 

    Description: Port naming directive to the tool while automatically creating the 
                 top module ports by prefixing with the module or instance name.

    Options    : -none boolean switch to clear previously set prefix directive
                 -module_name boolean switch to prepend the containing module name
                              while pulling the unconnected port to the top module.
                              You may find more number of ports in the to module 
                              if you use this switch.
                 -inst_name boolean switch to prepend the respective instance name
                              while pulling the unconnected pin to the top module.
                              This swich may result even further more number of ports
                              at the top lete. So, use this switch only when you really need it.

    Example    :  baya_set_top_module_auto_port_prefix -module_name
                  baya_set_top_module_auto_port_prefix -inst_name

                
[20] Command : baya_set_top_module_auto_port_suffix 

    Description: Port naming directive to the tool while automatically creating the 
                 top module ports by suffixing with the module or instance name.

    Options    : -none boolean switch to clear previously set suffix directive
                 -module_name boolean switch to append the containing module name
                              while pulling the unconnected port to the top module.
                              You may find more number of ports in the to module 
                              if you use this switch.
                 -inst_name boolean switch to append the respective instance name
                              while pulling the unconnected pin to the top module.
                              This swich may result even further more number of ports
                              at the top lete. So, use this switch only when you really need it.

    Example    :  baya_set_top_module_auto_port_suffix -module_name
                  baya_set_top_module_auto_port_suffix -inst_name

                
[21] Command : baya_add_connection 

    Description: Creates connection between the source port or pin and the destination 
                 port or pin. The source could be a input port of the top module or
                 output pin of an instance. The destination can be an output of the 
                 top module or input pin of an instance.  Also see the command
                 baya_auto_connect for automatic connections .
    Options    : 
                 -src <port/pin/interface name> , mandatory option to specify from where the 
                                           connection starts
                 -dest <port/pin/interface name> , mandatory option to specify to where the 
                                            connection ends
                                            You can provide multiple destinations separated with comma.
                                            Note that there is not space between the commas.
                 -ifdef_var <macro name> , optional input, to specify the macro enclosing this port map
                 -netname <connecting wire name> , optional( use only if you need ) switch 
                                            to specify the the name of the connecting wire when
                                            connecting two instance ports/bits/slices. Baya can
                                            internally generate this wire name if user
                                            does not provide this switch. In presence of
                                            this switch, Baya will declare this net in the
                                            current module and establish the connection with this.
                 -intf_port_maps <formal1@actual1/formal2@actual2>, optional input for the port maps of the interface which will
                                                                    connect the two instances' interfaces
                 -intf_param_maps <param1=value/param2=value>, optional input for the parameter maps for the interface which will
                                                               connect the two instances' interfaces
                 -comment <"Inline comments to be printed"> , Provide comments in quotes
                                            which will get printed next to this port mapping.
                                            This option must be used as the last option of this command.

    Example    : baya_add_connection -src input1  -dest instance_1.in1 -comment "This is comment"
                 baya_add_connection -src input1  -dest inst1.in1,inst2.in2,out3
                 baya_add_connection -src inst_1.out1  -dest instance_2.in1[0]
                 baya_add_connection -src inst_1.out1  -dest out -ifdef_var PWR
                 baya_add_connection -src inst_1.out1(0)  -dest instance_2.in1(3)
                 baya_add_connection -src inst_1.out1(3:1)  -dest instance_2.in1(7:9)
                 baya_add_connection -src inst_1.out1  -dest instance_2.in1 -netname mynet_out1_in1
                 baya_add_connection -src inst_1.out1(3:1)  -dest instance_2.in1(4:2) -netname p_net1280_addr
                 baya_add_connection -src inst_1.out1(0)  -dest instance_2.in1(3) -netname p_0_1_0_2_a_addr
                
[22] Command : baya_add_connection_pattern_based 

    Description: Creates connections between the source pin(s) and the destination 
                 pin(s) matching with the pattern/regular-expression. 
                 Also see the command baya_auto_connect for automatic connections .
    Options    : 
                 -src <inst name>.<output pin pattern> , mandatory option to specify the driving
                                           instance pin. Example:   inst1.clk.*out.*
                 -dest <inst name>.<input pin pattern> , mandatory option to specify to where the 
                                            connection ends. Example:  inst2.data.*in.*
                 -swap_src_dest , optional boolean switch to enable the values of the -src nd -dest

    Example    : baya_add_connection_pattern_based -src inst1.clk.*out.*  -dest inst2.data.*in.*
                 baya_add_connection_pattern_based -src u_clkgen.clk.*out.*  -dest u_dram.data.*in.* -swap_src_dest
                       The behavior of the -swap_src_dest is that, it will internally run this command twice as below-
                                 baya_add_connection_pattern_based -src u_clkgen.clk.*out.*  -dest u_dram.data.*in.* 
                                 baya_add_connection_pattern_based -src u_dram.data.*in.*  -dest u_clkgen.clk.*out.*
                
[23] Command : baya_add_constant_connection 

    Description: Drives the input pin of an instance or the output port of the
                 current design/module with the specified constant value.
    Options    : 
                 -value <constant value> , mandatory option to provide the constant value.
                                           It supports constant values in the verilog format.
                                           Example, 3'b101 or 16'hdead .
 
                 -dest <port or pin name> , mandatory option to specify to where the 
                                            constant value should get connected/assigned to. 
                                            You can provide multiple destinations separated with comma.
                                            Note that there is not space between the commas.
                 -ifdef_var <macro name> , optional input, to specify the macro enclosing this port map
                 -comment <"Inline comments to be printed"> , Provide comments in quotes
                                            which will get printed next to this port mapping.
                                            This option must be used as the last option of this command.

    Example    : baya_add_constant_connection -value 3'b101  -dest instance_1.in1
                 baya_add_constant_connection -value 16'hdead  -dest instance_2.in1
                 baya_add_constant_connection -value 15.out1  -dest out
                 baya_add_constant_connection -value 16'hdead  -dest inst.in1,inst2.in2,out3
                
[24] Command : baya_add_empty_connection 

    Description: Creates empty/open port connection for an instance
    Options    : 
 
                 -pin <instance pin name> , mandatory option to specify the
                                            instance pin name to keep open
                 -ifdef_var <macro name> , optional input, to specify the macro enclosing this port map
                 -comment <"Inline comments to be printed"> , Provide comments in quotes
                                            which will get printed next to this port mapping.
                                            This option must be used as the last option of this command.

    Example    : baya_add_empty_connection -pin instance_1.in1
                
[25] Command : baya_create_hierarchy 

    Description: Creates a new hierarchy by enclosing the list of instances in the 
                 given module. It internally creates a new module with the name specified 
                 name and then instantiates the given list of instances in that new module.
                 This way one new hierarchy get created in the given module.

    Options    :  
                 -insts <instance list> , mandatory option to provide  list of instances 
                                              separated with comma(,). These instances must be present
                                              in the given module. 
                 -new_inst_name <name> , mandatory option for the new hierarchy name 
                 -new_mod_name <name> , mandatory option for the new module name enclosing the instances

    Example    : baya_create_hierarchy -insts inst1,inst2,inst3 -new_inst_name newInst -new_mod_name wrapperMod
                
[26] Command : baya_create_sv_interface_instance 

    Description: Instantiates an interface inside the current module. The name of the interface which
                 gets instantiated is specified with the -intf switch. The name of the instance
                 is specified with the -name switch of this this function.
    Options    : 
                 -name <interface instance name> , the name of the interface instance to be created. 
                 -intf <interface name> , the name of the bus interface which is to be instantiated
                 -range <range> , optional switch to specify the range e.g -range 7:0 
    Example    : baya_create_sv_interface_instance -name my_inst_1 -intf ahb_intf
                
[27] Command : baya_create_sv_structure_object 

    Description: Instantiates a structure inside the current module. The name of the structure which
                 gets instantiated is specified with the -structure switch. The name of the instance
                 is specified with the -name switch of this this function.
    Options    : 
                 -name <obj name> , the name of the structure instance to be created. 
                 -struct <structure name> , the name of the already defined structure which is to be instantiated
    Example    : baya_create_sv_structure_object -name my_obj -struct mystructdef
                
[28] Command : baya_create_instance 

    Description: Instantiates a module inside the current module. The name of the module which
                 gets instantiated is specified with the -master switch. The name of the instance
                 is specified with the -name switch of this this function.
    Options    : 
                 -name <instance name> , the name of the instance to be created. 
                 -master <master module name> , the name of the Verilog module which is to be instantiated
                 -vlnv <IP-XACT Component VLNV> , the VLNV of the IP-XACT
                        Component to be instantiated. The Component will be
                        picked up from the search path(s). The VLNV should
                        be '/' separated Vendor, Library, Name, Version e.g.
                        edautils.com:compLib:uart:1.3


    Example    : baya_create_instance -name my_inst_1 -master mod1
                 baya_create_instance -name my_inst_1 -vlnv edautils.com/compLib/uart/1.3
                
[29] Command : baya_create_instances 

    Description: Creates multiple instances of same or different modules based upon the colon(:) separated instance&module pairs.
    Options    : 
                 -insts <instance-module pairs> , comma separated list containing instance name and module name in the brace e.g. inst1(mod1),inst2(mod1),inst3(mod3)
    Example    : baya_create_instances -insts inst1(mod1),inst2(mod1),inst3(mod3)

                    This command will create an instance named 'inst1' of the module 'mod1', another instance named 'inst2' of the module 'mod1', an instance named 'inst3' of the module 'mod3' .  

                
[30] Command : baya_create_module 

    Description: Creates new module with the specified name and sets 
                 as the same current module.
    Options    : 
                 -name <module name> , the name of the module to be created.
                 Note that this module will get set as the currrent module/design.

    Example    : baya_create_module -name mod1
                
[31] Command : baya_create_local_parameter 

    Description: Creates a local parameter in the current module or the in the module 
                 specified with the -module switch. The name of the localparam and its
                 value will be the one passed with the -name and the value switches.
    Options    : 
                 -name <param name> , mandatory input, the name of the parameter to be created.
                 -value <param value> , mandatory input, the value of the parameter to be set to. 
                 -module <module name> , optional input, name of the module where this parameter
                                         is to be created. If not specified then the parameter will 
                                         get created the current module.
    Example    : baya_create_local_parameter -name param1 -value 10 -module mod1
                
[32] Command : baya_create_parameter 

    Description: Creates a parameter in the current module or the in the module 
                 specified with the -module switch. The name of the parameter and its
                 value will be the one passed with the -name and the value switches.
    Options    : 
                 -name <param name> , mandatory input, the name of the parameter to be created.
                 -value <param value> , mandatory input, the value of the parameter to be set to. 
                 -module <module name> , optional input, name of the module where this parameter
                                         is to be created. If not specified then the parameter will 
                                         get created the current module.
    Example    : baya_create_parameter -name param1 -value 10 -module mod1
                
[33] Command : baya_create_parameter_map 

    Description: Overrides a parameter with the new value for the given instance.
                 It creates a parameter map in the given instance.
    Options    : 
                 -inst <inst name> , mandatory input, the name of the instance.
                 -param <param name> , mandatory input, name of the parameter whose 
                                      value to be set to.
                 -value <param value> , mandatory input, the value of the parameter to be set to.
    Example    : baya_create_parameter_map -inst instance_1 -param param1 -value 10
                
[34] Command : baya_create_port_map 

    Description: Creates and then adds a port map in a module or interace instance
    Options    : 
                 -formal <hierarchical pin name> , mandatory input, to provide
                           the port name of the interface or module instnace,
                           example intfref.clk or inst.clk
                 -actual <value to be associated> , mandatory input to associate
                           with the specified formal port of the instance or
                           interface. This value can be a local net or port of
                           the current design/module
    Example    : baya_create_port_map -formal inst1.clk -actual wire1
                
[35] Command : baya_create_interface_map 

    Description: Creates and then adds an interface map in a module instance
    Options    : 
                 -formal <hierarchical intf name> , mandatory input, to provide
                           the interface name of the module instnace, example
                           u_modem.ahb_intf 
                 -actual <interface reference to be associated> , mandatory
                           input interface instnace( this can be locally 
                           declared intf instance or current top module's port) 
    Example    : baya_create_interface_map -formal inst1.ahb_intf -actual ahb_intf
                
[36] Command : baya_create_net 

    Description: Creates a net in the current module or in the module specified module.
    Options    : 
                 -name <wire name> , mandatory input, name of the net be created
                 -range <left-bound:right-bound> , optional input, range for the vector net/bus
                 -module <module name> , optional input, name of the module where this net 
                                         is to be created. If not specified then the net will 
                                         get created in the current module.
    Example    : baya_create_net -module myMod -name net1 -range 2:0
                
[37] Command : baya_create_port 

    Description: Creates a port in the current module or in the module specified module.
    Options    : 
                 -name <port name> , mandatory input, name of the port be created
                 -dir <in|out|inout> , mandatory input, direction of the port be created
                 -range <left-bound:right-bound> , optional input, range for the vector port or bus
                 -module <module name> , optional input, name of the module where this port 
                                         is to be created. If not specified then the port will 
                                         get created in the current module.
    Example    : baya_create_port -module myMod -name port1 -dir in -range 2:0
                
[38] Command : baya_create_port_user_defined_type 

    Description: Creates a port in the current module or in the module specified module.
    Options    : 
                 -name <port name> , mandatory input, name of the port be created
                 -dir <in|out|inout> , mandatory input, direction of the port be created
                 -type <typename> , mandatory input to specify the data-type name e.g. structure name
                 -module <module name> , optional input, name of the module where this port 
                                         is to be created. If not specified then the port will 
                                         get created in the current module.
    Example    : baya_create_port_user_defined_type -name port1 -dir in -type mystruct_t
                
                Use the command baya_add_ranges_or_dimensions_in_object to add packed/unpacked dimension(s) to this port.
                
[39] Command : baya_add_ranges_or_dimensions_in_object 

    Description: Adds the given comma separated ranges in the packed or unpacked
                 dimension list of the specified port or net
    Options    : 
                 -name <name> , mandatory input, name of the port or net where
                                the given ranges is to be added 
                 -ranges 1:0,3:0 , mandatory input, comma separated ranges to
                                   be added in the dimension list
                 -packed , optional boolean switch to specify if the given
                           ranges belong to 'packed' dimension list. In absence
                           of this switch, the given ranges will be added in
                           the uppacked dimension list.
                 -module <module name> , optional input, name of the module
                         where this port belongs. If not specified then the 
                         port will get searched in the current module.

    Example    : baya_add_ranges_or_dimensions_in_object -module myMod -name port1 -packed ranges 7:0,3:0
                 baya_add_ranges_or_dimensions_in_object -name net1 -ranges 7:0,3:0
                
[40] Command : baya_create_port_sv_interface_type 

    Description: Creates interface type port in the current module or in the module specified module.
    Options    : 
                 -name <port name> , mandatory input, name of the port be created
                 -type <typename> , mandatory input to specify the data-type name e.g. structure name
                 -range <7:0> , optional input to specify range
                 -module <module name> , optional input, name of the module where this port 
                                         is to be created. If not specified then the port will 
                                         get created in the current module.
    Example    : baya_create_port_sv_interface_type -name port1 -type bus_intf.modport 
                
[41] Command : baya_elaborate 

    Description: Elaborates a module
    Options    : 
                 -module <module name> , optional input, name of the module which 
                                         is to be elaborated. The current module be elaborated
                                         if the this switch is not provided.
    Example    : baya_elaborate -module myMod 
                
[42] Command : baya_elaborate_root 

    Description: Elaborates a design database root
    Options    : 
    Example    : baya_elaborate_root 
                
[43] Command : baya_find_all_gate_instances 

    Description: Returns list of verilog primitive gate instances in the current module.
    Options    : 
    Example    : baya_find_all_gate_instances 
                
[44] Command : baya_find_all_module_instances 

    Description: Returns list of module instances in the current module.
    Options    : 
    Example    : baya_find_all_module_instances 
                
[45] Command : baya_find_all_udp_instances 

    Description: Returns list of udp instances in the current module.
    Options    : 
    Example    : baya_find_all_udp_instances 
                
[46] Command : baya_find_all_modules 

    Description: Returns list of all modules in the current design database in the memory.
    Options    : 
    Example    : baya_find_all_modules 
                
[47] Command : baya_find_all_nets 

    Description: Returns list of nets in the current module.
    Options    : 
    Example    : baya_find_all_nets
                
[48] Command : baya_find_all_ports 

    Description: Returns list of ports of the current module.
    Options    : 
    Example    : baya_find_all_ports 
                
[49] Command : baya_find_gate_instances 

    Description: Returns list of verilog primitive instances with name matching 
                 with the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match
                                                         the instance names
    Example    : baya_find_gate_instances -name ".*"
                
[50] Command : baya_find_hier_gate_instances 

    Description: Returns list of verilog primitive instances with hierarchical name 
                 matching with the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match the 
                                                         hierarchical instance names
    Example    : baya_find_hier_gate_instances -name ".*"
                
[51] Command : baya_find_hier_module_instances 

    Description: Returns list of verilog module instances with hierarchical 
                 name matching with the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match 
                                                         the hierarchical instance names
    Example    : baya_find_hier_module_instances -name ".*" 
                
[52] Command : baya_find_hier_nets 

    Description: Returns list of hierarchical nets with name matching with the 
                 regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match 
                                                         the hierarchical net names
    Example    : baya_find_hier_nets -name ".*" 
                
[53] Command : baya_find_hier_ports 

    Description: Returns list of hierarchical ports/pin with name matching with 
                 the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match 
                                                         the hierarchical port names
    Example    : baya_find_hier_ports -name ".*" 
                
[54] Command : baya_find_hier_udp_instances 

    Description: Returns list of verilog udp instances with hierarchical name 
                 matching with the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match 
                                                         the hierarchical instance names
    Example    : baya_find_hier_udp_instances -name ".*" 
                
[55] Command : baya_find_gate_instances 

    Description: Returns list of verilog primitive instances with name matching 
                 with the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match
                                                         the instance names
    Example    : baya_find_gate_instances -name ".*"
                
[56] Command : baya_find_module_instances 

    Description: Returns list of verilog module instances with name matching 
                 with the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match
                                                         the instance names
    Example    : baya_find_module_instances -name ".*" 
                
[57] Command : baya_find_nets 

    Description: Returns list of nets with name matching with the regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match 
                                                         the net names 
    Example    : baya_find_nets -name ".*" 
                
[58] Command : baya_find_ports 

    Description: Returns list of ports with name matching with the regular expression
    Options    :
                 -name <pattern or regular expression> , mandatory input, to match 
                                                         the port names 
    Example    : baya_find_ports -name ".*" 
                
[59] Command : baya_find_udp_instances 

    Description: Returns list of udp instances with name matching with the 
                 regular expression
    Options    : 
                 -name <pattern or regular expression> , mandatory input, to match
                                                         the instance names
    Example    : baya_find_udp_instances -name ".*"
                
[60] Command : baya_import_ipxact 

    Description: Reads the specified IP-XACT component or design xml file 
    Options    : 
                 -component <IP-XACT component XML file name> , Component XML
                 -design <IP-XACT Design XML file name> , Design XML , you
                         should specify the component with the -component
                         switch corresponding to this design in order to create
                         the ports/params in the generated Verilog/VHDL design
                 -merge_mmap , optional boolean switch to specify that memory
                              from this Component needs to be merged with the
                              previously loaded component with same name as this
                              Default false and useful only with the -component switch.
    Example    : baya_import_ipxact -component foo.component.xml 
                 baya_import_ipxact -design Leon_Design.xml  -component Leon.xml
                
[61] Command : baya_ipxact_add_component 

    Description: Adds the specified IP-XACT component object on the database
    Options    : 
                 -component <IP-XACT Component> , Component type object
                 -merge_mmap , optional boolean switch to specify that memory
                              from this Component needs to be merged with the
                              previously loaded component with same name as this
                              Default false 
    Example    : baya_ipxact_add_component -component $compObj
                
[62] Command : baya_ipxact_component_add_memorymap 

    Description: Inserts the given IP-XACT MemoryMap into the specified Component
    Options    : 
                 -component <Component VLNV> , the VLNV in separated with '/' of the
                              Component inside which the given MemoryMap to be inserted.
                              If you want to associate Memory Map with a Verilog Module,
                              then just pass the name of the Module which is already imported in the database.
                 -xml <AddrBlk.xml> , switch to specify the IP-XACT file containing the MemoryMap(s) or AddressBlock which is to be inserted 
    Example    : baya_ipxact_component_add_memorymap -component synopsys/lib/DDR/1.5 -xml mmap.xml
                
[63] Command : baya_ipxact_component_object_add_memorymap 

    Description: Inserts the given IP-XACT MemoryMap into the specified Component Object
    Options    : 
                 -component <Component Object> , the Component Object
                 -xml <AddrBlk.xml> , switch to specify the IP-XACT file containing the MemoryMap(s) or AddressBlock which is to be inserted 
    Example    : baya_ipxact_component_object_add_memorymap -component $compObj -xml mmap.xml
                
[64] Command : baya_ipxact_component_object_add_memorymap 

    Description: Inserts the given IP-XACT MemoryMap into the specified Component Object
    Options    : 
                 -component <Component Object> , the Component Object
                 -xml <AddrBlk.xml> , switch to specify the IP-XACT file containing the MemoryMap(s) or AddressBlock which is to be inserted 
    Example    : baya_ipxact_component_object_add_memorymap -component $compObj -xml mmap.xml
                
[65] Command : baya_ipxact_convert_verilog_module_into_component 

    Description: Creates IP-XACT component corresponding to a Verilog Module
    Options    : 
                 -module <Module Name> , name of the module which is to be converted into IP-XACT Component
    Example    : baya_ipxact_convert_verilog_module_into_component -module i2c
                
[66] Command : baya_generate_rsa_keys 

    Description: Generate public and private key files
    Options    : 
                 -pvtkey <file name>, input to specify the private key file name
                 -pubkey <file name>, input to specify the public key file name
    Example    : baya_generate_rsa_keys -pvtkey key.pvt.dat -pubkey key.pub.dat
                
[67] Command : baya_preprocess_verilog 

    Description: Reads the given input file and writes back the preprocessed
                 output file
    Options    : 
                 -in <input file name> , mandatory input, to specify the
                                         input file name
                 -out <ioutput file name> , mandatory input, to specify the
                                         output file name
                 -incdir <directories> , optional input, directories where include
                                         files to be searched 
                 -definedir <macros to be defined> , optional input, directives to
                                                     be defined 
                 -pubkey <public key file> input to pass the public keyfile 
                                        with which the data will get decrypted.
                                        This input is mandatory for decryption.
                 -key <key for encrytption> , input to pass the key with which
                                        the data will get encrypted. This input
                                        is must while encryption and not 
                                        required while decrypting an encrypted
                                        file. However, the private is must in
                                        order to decrypt a file. 
                 -pvtkey <private keyfile name> , to specify the name of the
                                         private key file. This input is must 
                                         in order to decrypt an encrypted input
                                         file. It is optional when you call this
                                         to encrypt a file. While encryption,
                                         the private key will get dumped in this
                                         file. 
                 -keyowner <Owner of the key> , Optional input to specify 
                                         the name of the key owner. Generally,
                                         name of the company is specified here.
                 -keyname <name of the key> , Optional input to specify 
                                         the name of the key. 
                 -commented , optional boolean switch to specify if 
                              the 'protect' directives should be inside 
                              the '//' instead of the '`pragma'. By default
                              its false.
                 -algo <algo name> , optional input, to pass the name of the
                                     algorithm which will be used to decrypt 
                                     the protected functionality. Default is
                                     value AES. 
    Example (for encryption)   : baya_preprocess_verilog -in foo.v -out processed.v -incdir dir1+dir2  -definedir define+macro1+macro2 -key edautils_dot_com  -pubkey pubkey.dat -keyowner SiliconIndia -keyname SI_001
    Example(for decryption)    : baya_preprocess_verilog -in foo.v -out processed.v -incdir dir1+dir2  -definedir define+macro1+macro2 -pvtkey pvtkey.dat -keyowner SiliconIndia -keyname SI_001
                
[68] Command : baya_import_verilog 

    Description: Imports the specified verilog file so that the module can be instantiated.
    Options    : 
                 -file <file name> , mandatory input, file to be read
                 -excludefilelist <exclude.list> , optional input to exclude 
                                                  files listed in the given file
                 -top <module to be imported> , mandatory input, top module in this file
                 -incdir <directories> , optional input, directories where include
                                         files to be searched 
                 -definedir <macros to be defined> , optional input, directives to
                                                     be defined 
                 -nowildcard , optional boolean switch to disable wildcard processing in file name(s)
                 -key <key for encrytption> , mandatory input while encrypting
                 -pvtkey <private keyfile name> , mandatory input while
                                         while encrypting an input file. This
                                         file can be created if does not exists
                                         with the command baya_generate_rsa_keys
                 -pubkey <public keyfile name> , to specify the name of the
                                         public key file. This input is must 
                                         in order to decrypt an encrypted input
                                         file. 
                 -keyowner <Owner of the key> , Optional input to specify 
                                         the name of the key owner. Generally,
                                         name of the company is specified here.
                 -keyname <name of the key> , Optional input to specify 
                                         the name of the key. 
                 -algo <algo name> , optional input, to pass the name of the
                                     algorithm which will be used to decrypt 
                                     the protected functionality. Default is
                                     value AES. 
    Example    : baya_import_verilog -file foo.v -top myTop -incdir dir1+dir2  -definedir define+macro1+macro2
                
[69] Command : baya_import_verilog_filelist 

    Description: Imports the specified multiple verilog files listed in the input file
    Options    : 
                 -filelist <list file> , mandatory input, file where verilog files
                                          are listed 
                 -excludefilelist <exclude.list> , optional input to exclude 
                                                  files listed in the given file
                 -top <module to be imported> , mandatory input, top module in this file
                 -incdir <directories> , optional input, directories where include
                                         files to be searched 
                 -definedir <macros to be defined> , optional input, directives to
                                         be defined 
                 -nowildcard , optional boolean switch to disable wildcard processing in file name(s)
                 -key <key for encrytption> , mandatory input while encrypting
                 -pvtkey <private keyfile name> , mandatory input while
                                         while encrypting an input file. This
                                         file can be created if does not exists
                                         with the command baya_create_rsa_keys .
                 -pubkey <public keyfile name> , to specify the name of the
                                         public key file. This input is must 
                                         in order to decrypt an encrypted input
                                         file. 
                 -keyowner <Owner of the key> , Optional input to specify 
                                         the name of the key owner. Generally,
                                         name of the company is specified here.
                 -keyname <name of the key> , Optional input to specify 
                                         the name of the key. 
                 -algo <algo name> , optional input, to pass the name of the
                                     algorithm which will be used to decrypt 
                                     the protected functionality. Default is
                                     value AES. 
    Example    : baya_import_verilog_filelist -filelist infile.list -top myTop -incdir dir1+dir2  -definedir define+macro1+macro2
                
[70] Command : baya_import_verilog_file_list 

    Description: Imports the specified multiple verilog files listed in the input file
    Options    : 
                 -file_list <list file> , mandatory input, file where verilog files
                                          are listed 
                 -excludefilelist <exclude.list> , optional input to exclude 
                                                  files listed in the given file
                 -top <module to be imported> , mandatory input, top module in this file
                 -incdir <directories> , optional input, directories where include
                                         files to be searched 
                 -definedir <macros to be defined> , optional input, directives to
                                         be defined 
                 -nowildcard , optional boolean switch to disable wildcard processing in file name(s)
                 -key <key for encrytption> , mandatory input while encrypting
                 -pvtkey <private keyfile name> , mandatory input while
                                         while encrypting an input file. This
                                         file can be created if does not exists
                                         with the command baya_create_rsa_keys .
                 -pubkey <public keyfile name> , to specify the name of the
                                         public key file. This input is must 
                                         in order to decrypt an encrypted input
                                         file. 
                 -keyowner <Owner of the key> , Optional input to specify 
                                         the name of the key owner. Generally,
                                         name of the company is specified here.
                 -keyname <name of the key> , Optional input to specify 
                                         the name of the key. 
                 -algo <algo name> , optional input, to pass the name of the
                                     algorithm which will be used to decrypt 
                                     the protected functionality. Default is
                                     value AES. 
    Example    : baya_import_verilog_file_list -file_list infile.list -top myTop -incdir dir1+dir2  -definedir define+macro1+macro2
                
[71] Command : baya_import_vhdl 

    Description: Imports the specified VHDL file
    Options    : 
                 -file <VHDL file name> , mandatory input, name of the VHDL to be read
                 -top <entity to be imported> , mandatory input, entity defined in this file 
                 -work <work lib name> , optional input, to specify the work library
                 -mapfile <map file> , optional input, logical to physical library 
                                       map file. Each line in this mapfile should 
                                       be similar to below.

                                        WORK=/home/klg/vhdl_dumps/work
                                        GATE=/home/klg/vhdl_dumps/gatelib
                                        CORE=/home/klg/vhdl_dumps/core

    Example    : baya_import_vhdl -file foo.vhd -work work -mapfile libmap.ini
                
[72] Command : baya_import_vhdl_filelist 

    Description: Imports the specified VHDL file
    Options    : 
                 -filelist <VHDL filelist name> , mandatory input, name of the VHDL filelist
                 -top <entity to be imported> , mandatory input, entity defined in this file 
                 -work <work lib name> , optional input, to specify the work library
                 -mapfile <map file> , optional input, logical to physical library 
                                       map file. Each line in this mapfile should 
                                       be similar to below.

                                        WORK=/home/klg/vhdl_dumps/work
                                        GATE=/home/klg/vhdl_dumps/gatelib
                                        CORE=/home/klg/vhdl_dumps/core

    Example    : baya_import_vhdl_filelist -file foo.vhd -work work -mapfile libmap.ini
                
[73] Command : baya_import_mixed_hdl_filelist 

    Description: Imports the specified multiple Verilog and VHDL files listed in the input list file
    Options    : 
                 -filelist <list file> , mandatory input, file where VHDL and
                                         Verilog files are listed 
                 -excludefilelist <exclude.list> , optional input to exclude 
                                                  files listed in the given file
                 -top <module to be imported> , mandatory input, top module in this file
                 -incdir <directories> , optional input, directories where include
                                         files to be searched 
                 -definedir <macros to be defined> , optional input, directives to
                                         be defined 
                 -nowildcard , optional boolean switch to disable wildcard processing in file name(s)
    Example    : baya_import_mixed_hdl_filelist -filelist infile.list -top myTop -incdir dir1+dir2  -definedir define+macro1+macro2
                
[74] Command : baya_set_ansi_header_print_verilog 

    Description: Disable/enable ANSI style header while printing the verilog modules
    Options    : 
                 -value <true|false> , mandatory input - only true or false is allowed
    Example    : baya_set_ansi_header_print_verilog -value false
                
[75] Command : baya_print_verilog 

    Description: Prints the current module or the one specified with the switch -module 
    Options    : 
                 -module <module name> , optional input, name of the module which 
                                         is to be printed. The current module be
                                         printed if the this switch is not provided.
                 -key <key for encrytption> , input to pass the key with which
                                        the data will get encrypted. This input
                                        is must while encryption and not 
                                        required while decrypting an encrypted
                                        file. Howver, the private is must in
                                        order to decrypt a file. 
                 -pubkey <public keyfile name> , to specify the name of the
                                         public key file
                 -keyowner <Owner of the key> , Optional input to specify 
                                         the name of the key owner. Generally,
                                         name of the company is specified here.
                 -keyname <name of the key> , Optional input to specify 
                                         the name of the key. 
                 -commented_directive  , optional boolean switch to specify if the
                                       'protect' directives to be printed 
                                       as '// protect ...' . Default is
                                       false and by default it'll print the same
                                       as '`pragma protect ...' 
    Example    : baya_print_verilog -key edautils_dot_com  -pubkey publickey.dat -keyowner SiliconIndia -keyname SI_001
                
[76] Command : baya_print_verilog_file 

    Description: Prints the current module or the one specified with the 
                 switch -module in the file set with baya_set_file command.
                 In other words, this saves the DB as verilog log database.
                 This is implementation of baya_save_as_verilog_file  command.

    Options    : 
                 -module <module name> , optional input, name of the module which 
                                         is to be printed. The current module be
                                         printed if the this switch is not provided.
                 -file <file name> ,     optional input to specify the file name
                 -key <key for encrytption> , input to pass the key with which
                                        the data will get encrypted. This input
                                        is must while encryption and not 
                                        required while decrypting an encrypted
                                        file. Howver, the private is must in
                                        order to decrypt a file. 
                 -pubkey <public keyfile name> , to specify the name of the
                                         public key file
                 -keyowner <Owner of the key> , Optional input to specify 
                                         the name of the key owner. Generally,
                                         name of the company is specified here.
                 -keyname <name of the key> , Optional input to specify 
                                         the name of the key. 
                 -commented_directive  , optional boolean switch to specify if the
                                       'protect' directives to be printed 
                                       as '// protect ...' . Default is
                                       false and by default it'll print the same
                                       as '`pragma protect ...' 
    Example    : baya_print_verilog_file -key edautils_dot_com  -pubkey publickey.dat -keyowner SiliconIndia -keyname SI_001 -file output.v 
                
[77] Command : baya_print_empty_module 

    Description: Prints the specifiled module or the current module in the file.
                 
    Options    : 
                 -module <module name> , name of the module which is to be
                                         printed by stripping the functionality
                 -file <file name> ,     optional input to specify the file name
                 -no_includes , optional boolean switch to disable printing
                                of the include files.
    Example    : baya_print_empty_module -module foo  -file foo.nobody.v
                
[78] Command : baya_print_csv_for_integration 

    Description: Prints integration intent( input ports ) of the module or the current module in the file.
                 
    Options    : 
                 -module <module name> , name of the module for which CSV to be printed
                 -file <file name> ,     the CSV file name where inputs pins, params to be listed
    Example    : baya_print_csv_for_integration -module foo  -file foo.csv
                
[79] Command : baya_print_vhdl 

    Description: Prints in VHDL the current module or the one specified with
                 the switch -module .
    Options    : 
                 -module <module name> , optional input, name of the module which 
                                         is to be printed. The current module be 
                                         printed if the this switch is not provided.
    Example    : baya_print_vhdl -module myMod
                
[80] Command : baya_print_vhdl_file 

    Description: Prints in VHDL the current module or the one specified with the 
                 switch -module in the file set with baya_set_file command.
    Options    :  
                 -module <module name> , optional input, name of the module which 
                                         is to be printed. The current module be
                                         printed if the this switch is not provided.
                 -file <file name> , optional input, to specify the file name
                                     where the given module or the currently
                                     active module needs to printed.
    Example    : baya_print_vhdl_file -module myMod [-file foo.vhd]
                
[81] Command : baya_generate_ipxact_component_c_model 

    Description: Creates C/H model corresponding to the specified IP_XACT component which is already imported into the database
                 
    Options    : 
                 -component <component name> , name of the component which needs to be translated into C/H Model
                 -reg_value_accssor <name> , optional switch to specify the name of
                           the accessor corresponding to REGISTER value, default is 'value' ,
                           get reg value as <reg name>.value 
                 -reg_field_accssor <name> , optional switch to specify the name of the accessor
                          corresponding to REGISTER Bit Fileds, default is 'Fields' ,
                          get reg bit-fields as <reg name>.Fields
                 -v2014 , optional boolean switch to specify that the input IP-XACT version is 2014
                                         
                 -outdir <dir path> , output directory name where the C/H files need to be dumped

    Example    : baya_generate_ipxact_component_c_model -component i2c  -outdir csrc
                
[82] Command : baya_generate_ipxact_design_c_model 

    Description: Creates C/H model corresponding to the specified IP-XACT Design  or the current top design where IP-XACT components have been instantiated
                 
    Options    : 
                 -design <design name> , name of the design which needs to be translated into C/H Model
                 -mapfile <baseaddr.map> , the base address map file where each line
                             contains the overridden base address corresponding to
                             each instance's AddressBlock in the design. Example,
                                 instance_1/mmap1/addrblk1 = 0x00001024
                                 instance_2/mmap1/addrblk1 = 0x00002048
                                 instance_2/mmap2/addrblk1 = 0x00003072
                                         
                 -v2014 , optional boolean switch to specify that the input IP-XACT version is 2014
                 -outdir <dir path> , output directory name where the C/H files need to be dumped. Default directory is c_model
                 -reg_value_accssor <name> , optional switch to specify the name of
                           the accessor corresponding to REGISTER value, default is 'value' ,
                           get reg value as <reg name>.value 
                 -reg_field_accssor <name> , optional switch to specify the name of the accessor
                          corresponding to REGISTER Bit Fileds, default is 'Fields' ,
                          get reg bit-fields as <reg name>.Fields
                 -uniquify , boolean switch to uniquify the struct names based
                             upon the overidden config. element values in the
                             component instantion. Useful if same component gets
                             instantiatied multiple times with different 
                             register/memory configuration(s) . Default is false

    Example    : baya_generate_ipxact_design_c_model -design Leon -mapfile baseAddr.map -outdir csrc
                
[83] Command : baya_ipxact_design_get_all_address_block_hierarchical_names 

    Description: Returns a list of all address block ahierarchical names from the specified IP-XACT Design name ( ijust the name, not VLNV )
                 
    Options    : 
                 -design <design name> , name of the design from which the address blocks need to reported
    Example    : baya_ipxact_design_get_all_address_block_hierarchical_names -design Leon 
                
[84] Command : baya_remove_connection 

    Description: Removes connection between the source port or pin and the destination
                 port or pin. The source could be a input port of the top module or 
                 output pin of an instance. The destination can be an output of the
                 top module or input pin of an instance. 
    Options    : 
                 -src <port or pin name> , mandatory option to specify from where
                                           the connection starts 
                 -dest <port or pin name> , mandatory option to specify to where
                                            the connection ends 
    Example    : baya_remove_connection -src input1  -dest instance_1.in1
                 baya_remove_connection -src inst_1.out1  -dest instance_2.in1
                 baya_remove_connection -src inst_1.out1  -dest out
                
[85] Command : baya_remove_hierarchy 

    Description: Removes a hierarchy by flattening the the specified instance in the
                 current module. It internally pulls up the contents of the instance
                 in the current module.
    Options    : 
                 -inst <instance name> , mandatory option to provide the instance 
                 -all_levels  , optional boolean switch to specify if the hierarchy
                                of the subsequent lower levels to be removed 
    Example    : baya_remove_hierarchy -inst inst1 -all_levels
                
[86] Command : baya_remove_instance 

    Description: Removes the instance specified with the -name switch from the current module.
    Options    : 
                 -name <instance name> , the name of the instance to be removed. 
    Example    : baya_remove_instance -name inst1 
                
[87] Command : baya_get_maturity_status 

    Description: Calculates the RTL maturity status w.r.t connection of the instances 
    Options    : 
                 -module <design name> , optional input to specify the  design. 
    Example    : baya_get_maturity_status -module foo 
                
[88] Command : baya_create_wrapper_verilog_in_verilog 

    Description: Creates a Verilog wrapper module by instantiating the specified
                 module.

    Options    :
                 -module <module name>, mandatory input to specify the module
                                        name around which the wrapper needs to
                                        be generated.
                 -flatten , optional boolean switch to enable the splitting of
                            the multidimensional port arrays 
                 -wrapper <module name> optional switch to specify the name
                            of the wrapper module to be created.
                 -outfile <file name> optional switch to specify the name
                            of the output file where the wrapper module will
                            be written

    Returns    : The wrapper module object

    Example    : baya_create_wrapper_verilog_in_verilog -module originalModule  -wrapper wrapperModule -flatten -outfile wrapperModule.sv
                
[89] Command : baya_create_wrapper_vhdl_in_vhdl 

    Description: Creates a VHDL wrapper module by instantiating the specified
                 entity.

    Options    :
                 -entity <entity name>, mandatory input to specify the entity
                                        name around which the wrapper needs to
                                        be generated.
                 -wrapper <entity name> optional switch to specify the name
                                        of the wrapper entity to be created.
                 -outfile <file name> optional switch to specify the name of the output file where the
                                        wrapper entity and architecture will be written
                 -work <library name> , optional input to specify the library
                                        from where this entity to be loaded.
                                        Default library is 'work' 
                 -mapfile <library mapfile> , optional input to specify the
                                              logical to physical library map

    Returns    : The wrapper entity object

    Example    : baya_create_wrapper_vhdl_in_vhdl -entity originalEntity  -wrapper wrapperEntity -outfile wrapper.vhd
                
[90] Command : baya_clean_vhdl_design_database 

    Description: Cleans up the internal design database for fresh parsing of 
                 vhdl design units. This is would be required when comparing
                 two entities with same name. You should parse the files 
                 containing the golden entity/arch and then clean up the
                 design database to avoid the multiple definition error and
                 then parse the revised RTL file(s) containing the modified
                 definition of the same entity/arch.

    Options    : None
    Returns    : None

    Example    : baya_clean_vhdl_design_database
                
[91] Command : baya_clean_verilog_design_database 

    Description: Cleans up the internal design database for fresh parsing of 
                 modules. This is would be required when comparing two modules 
                 with same name. You should parse the files containing the 
                 golden module and then clean up the design database to avoid 
                 the multiple definition error and then parse the revised RTL
                 file(s) containing the modified definition of the same module.

    Options    : None
    Returns    : None

    Example    : baya_clean_verilog_design_database
                
[92] Command : baya_set_hdl_search_path 

    Description: Colon separated paths where the Veriloh/VHDL files to be searched

    Options    :
                 -paths <colon separated paths> , mandatory input to specify the
                              paths where from the referred VHD/Verilog file
                              should be picked up

    Returns    : None

    Example    : baya_set_hdl_search_path -paths /edautils/install:. 
                
[93] Command : baya_set_ipxact_search_path 

    Description: Colon separated paths where the components to bearched as 
                 per the VLNV 

    Options    :
                 -paths <colon separated paths> , mandatory input to specify the
                              paths where from the IP-XACT components/design/
                              busedfs be loaded as per the VLNV. This must be
                              used in the beginning or before loading component
                              or design XML.
                 -v2014 , optional boolean switch to specify that the input IP-XACT version is 2014

    Returns    : None

    Example    : baya_set_ipxact_search_path -paths /edautils/install:. 
                
[94] Command : baya_verilog_find_module 

    Description: Searches for the modules matching with the regular
                 expression


    Options    :
                 -name <module name> , mandatory input to specify the
                              module name which needs to be searched in the
                              design database

    Returns    : The module object matching with the name

    Example    : baya_verilog_find_module -name foo 
                
[95] Command : baya_vhdl_find_entity 

    Description: Returns the VHDL entity with the specified name

    Options    :
                 -name <entity name> , mandatory option to specify the entity
                                       name to be loaded
                 -work <library name> , optional input to specify the library
                                        from where this entity needs to be 
                                        loaded.  Default library is 'work' 
                 -mapfile <library mapfile> , optional input to specify the
                                              logical to physical library map

    Returns    : Returns the VHDL entity object

    Example    : baya_vhdl_find_entity -name foo [-work WORK] [-mapfile map.ini ]
                
[96] Command : baya_compare_verilog_modules 

    Description: Compare two verilog module's parameter's, ports, interfaces and instances

    Options    :
                 -golden <golden module name>, mandatory input to specify the golden
                                               module name. You must invoke the command
                                               baya_clean_verilog_design_database in between reading
                                               the golden and the revised Verilog files
 
                 -revised <revised module name>, mandatory input to specify the revised
                                               module name. You must invoke the command
                                               baya_clean_verilog_design_database in between reading
                                               the golden and the revised Verilog files
                 -ignore_insts , optional boolean switch to ignore comparsion of instanc(s), use this switch
                                              if you want to compare only the ports and parameters 

                 -ignore_assgns , optional boolean switch to ignore comparsion of concurrent statements, use this switch
                                              if you want to compare only the ports and parameters 
                 -outcsv <output CSV file name>, optional input to specify the file name
                                               where the diffs will be printed as CSV/XLS.
                                               Default file name is diff.csv 
 
                 -outtxt <output Text file name>, optional input to specify the file name
                                               where the diffs will be printed in text format
                                               Default file name is diff.txt 

    Returns    : None

    Example    : baya_compare_verilog_modules -golden mod_gld  -revised mod_rev -outcsv foo.csv -outtxt bar.txt
                
[97] Command : baya_compare_verilog_module_objects 

    Description: Compare two verilog module's parameter's, ports, interfaces and instances

    Options    :
                 -golden <golden module object>, mandatory input to specify the golden
                                               module object. You must invoke the command
                                               baya_clean_verilog_design_database in between reading
                                               the golden and the revised Verilog files
 
                 -revised <revised module object>, mandatory input to specify the revised
                                               module object. You must invoke the command
                                               baya_clean_verilog_design_database in between reading
                                               the golden and the revised Verilog files
                 -ignore_insts , optional boolean switch to ignore comparsion of instanc(s), use this switch
                                              if you want to compare only the ports and parameters 

                 -ignore_assgns , optional boolean switch to ignore comparsion of concurrent statements, use this switch
                                              if you want to compare only the ports and parameters 

                 -outcsv <output CSV file name>, optional input to specify the file name
                                               where the diffs will be printed as CSV/XLS.
                                               Default file name is diff.csv 
 
                 -outtxt <output Text file name>, optional input to specify the file name
                                               where the diffs will be printed in text format
                                               Default file name is diff.txt 

    Returns    : None

    Example    : baya_compare_verilog_module_objects -golden mod_gld  -revised mod_rev -outcsv foo.csv -outtxt bar.txt
                
[98] Command : baya_merge_modules 

    Description: Merges contents of two definitions of same module where two different sets of instances were grouped independently. This command will put them together as if both the group commands were executed in the same run.

    Options    :
                 -top <top module name>, mandatory input to specify the top module name
 
                 -instances <colon-separated-instances>, List of instances names separated with colon. Specify only instance name if the containing module name is same as 'top' otherwise specify the module name with '@' e.g. inst1@foo_mod
                 -seed_inst <instance name>, optional input to specify the seed instance name. All other grouped instances from other modueles will be pulled here.
                 -infile <verilog file name containing modules>, mandatory input to provide the module definition. Do not use this switch if you have multiple files, use -filelist in such case
                 -filelist <list file> , specify multiple files throug this switch. You to specify +incdir or +define directivies as applicable
                 -excludefilelist <list file> , optional switch to specify files to excluded from parsing while -filelis is used
                 -wildcard , optional boolean switch to accept wildcards in file name, try not to use this switch if you can
                 -noreparse , disables reparse of the merged module. By default, it save the merged module into a file are reparse it after every mering. Thouh it increases the runtime, it creates fresh symbol table.
                 -outfile <file name>, swicth to specify the output file name where the merged module will be saved

    Returns    : None

    Example    : baya_merge_modules -top top  -instances new_hier1:new_hier2@anothertop:new_hier3 -seed_inst new_hier5 -outfile merged.v
                
[99] Command : baya_clean_vhdl_design_database 

    Description: Cleans up the internal design database for fresh parsing of 
                 vhdl design units. This is would be required when comparing
                 two entities with same name. You should parse the files 
                 containing the golden entity/arch and then clean up the
                 design database to avoid the multiple definition error and
                 then parse the revised RTL file(s) containing the modified
                 definition of the same entity/arch.

    Options    : None
    Returns    : None

    Example    : baya_clean_vhdl_design_database
                
[100] Command : baya_compare_vhdl_entities 

    Description: Compare two vhdl entity's generics, ports and instances in the 
                 architectures( most recently compiled architecture )

    Options    :
                 -golden <golden entity name>, mandatory input to specify the golden
                                               entity name. You must invoke the command
                                               baya_clean_vhdl_design_database in between reading
                                               the golden and the revised VHDL files.
                                               You should compile the golden RTLs in golden library
                                               and revised RTLs in the revised library if the entity
                                               names are same
 
                 -revised <revised entity name>, mandatory input to specify the revised
                                               entity name. You must invoke the command
                                               baya_clean_vhdl_design_database in between reading
                                               the golden and the revised Verilog files
                                               Note: You should compile the golden RTLs in golden library
                                               and revised RTLs in the revised library if the entity
                                               names are same
                 -golden_work <golden work library name>, mandatory input to specify the golden work( logical )
                                               library name. Make sure that this library was used with
                                               the -work switch while reading/analyzing/importing the RTLs
                                               containing the golden entity/arch. Also ensure that your
                                               specified library exists in the mapfile passed through the -mapfile switch
                 -revised_work <revised work library name>, mandatory input to specify the revised work( logical )
                                               library name. Make sure that this library was used with
                                               the -work switch while reading/analyzing/importing the RTLs
                                               containing the revised entity/arch. Also ensure that your
                                               specified library exists in the mapfile passed through the -mapfile switch
                 -mapfile <mapfile name>, mandatory input to specify the VHDL library mappings.
                                               This map file needs to be created by the user thought any text editor.
                                               Each line should contain one library mapping, example-
                                               revised_wrk=/user/klg/vhdl/work/revised
                                               golden_wrk=/user/klg/vhdl/work/golden
                                               If your mapfile contains above two lines, then you can specify
                                               revised_wrk for the -revised_work and golden_wrk for the -golden_work

                 -outcsv <output CSV file name>, optional input to specify the file name
                                               where the diffs will be printed as CSV/XLS.
                                               Default file name is diff.csv 
 
                 -outtxt <output Text file name>, optional input to specify the file name
                                               where the diffs will be printed in text format
                                               Default file name is diff.txt 

    Returns    : None

    Example    : baya_compare_vhdl_entities -golden gld_entity  -revised modified_ent -golden_work work1 -revised_work work2 -mapfile mapfile.ini -outcsv diff.csv -outtxt diff.txt
                
[101] Command : baya_compare_vhdl_entity_objects 

    Description: Compare two VHDL entity objects- ports, interfaces and instances

    Options    :
                 -golden <golden entity object>, mandatory input to specify the golden
                                               entity object. You must invoke the command
                                               baya_clean_vhdl_design_database in between reading
                                               the golden and the revised VHDL files
 
                 -revised <revised entity object>, mandatory input to specify the revised
                                               entity object. You must invoke the command
                                               baya_clean_vhdl_design_database in between reading
                                               the golden and the revised VHDL files

                 -outcsv <output CSV file name>, optional input to specify the file name
                                               where the diffs will be printed as CSV/XLS.
                                               Default file name is diff.csv 
 
                 -outtxt <output Text file name>, optional input to specify the file name
                                               where the diffs will be printed in text format
                                               Default file name is diff.txt 

    Returns    : None

    Example    : baya_compare_vhdl_entity_objects -golden gld_ent  -revised rev_ent -outcsv foo.csv -outtxt bar.txt
                
[102] Command : baya_disable_connection_db 

    Description: Disables creation and population of the Baya connection database
    Options    : 
                 
    Example    : baya_disable_connection_db
                
[103] Command : baya_load_connection_db 

    Description: Loads the specified connection database to extract connection details

    Options    :
                 -xml <BayaConnDB.xml>, mandatory input to specify the Baya 
                         connection DB to be loaded. You need to set this 
                         as current Connection DB if you want to get it updated
                         while creating new Baya connection .

    Returns    : The BayaConnectionDB object corresponding to the specified file

    Example    : baya_load_connection_db -xml BayaConnDB.xml
                
[104] Command : baya_set_current_connection_db 

    Description: Sets the specified Connection DB Object as the current DB
                 so that new connections gets added into this database.

    Options    :
                 -db <BayaConnDB Object>, mandatory input to specify the Baya 
                         connection DB to be loaded. You need to set this 
                         as current Connection DB if you want to get it updated
                         while creating new Baya connection .

    Returns    : None

    Example    : baya_set_current_connection_db -db BayaConnDBObject
                
[105] Command : baya_get_current_connection_db 

    Description: Returns the currently active Baya Connection DB

    Options    :

    Returns    : The currently active Baya Connection DB object

    Example    : baya_get_current_connection_db 
                
[106] Command : baya_get_connected_instances 

    Description: Returns list of Baya Instances connected with the given
                 instances. Each item in the list of type BayaInstance
                 Returned Instances are extracted from the currently
                 active Connection DB

    Options    :
                 -inst <Instance Name>, the first instance name 

    Returns    : List of the Baya Instance Objects 

    Example    : baya_get_connected_instances -inst u_inst
                
[107] Command : baya_get_connections_between_instances 

    Description: Returns list of Baya connection object between instances.
                 Returned connections are extracted from the currently
                 active Connection DB

    Options    :
                 -insts <inst1:inst2 >, colon separated list of instances

    Returns    : List of the Baya Connection Objects 

    Example    : baya_get_connections_between_instances -insts inst1:inst2
                
[108] Command : baya_get_connections_between_two_instances 

    Description: Returns list of Baya connection object between two instances.
                 Returned connections are extracted from the currently
                 active Connection DB

    Options    :
                 -inst_1 <Instance Name>, the first instance name 
                 -inst_2 <Instance Name>, the second instance name 

    Returns    : List of the Baya Connection Objects 

    Example    : baya_get_connections_between_two_instances
                
[109] Command : baya_get_connections_between_instance_and_top 

    Description: Returns list of Baya connection object between instance and top
                 Returned connections are extracted from the currently
                 active Connection DB

    Options    :
                 -inst <Instance Name>, the instance name 

    Returns    : List of the Baya Connection Objects 

    Example    : baya_get_connections_between_instance_and_top
                
[110] Command : baya_get_bayadb_instance_name 

    Description: Returns the name of the specified Baya DB instance 

    Options    :
                 -inst <Instance Object>, the instance Object 

    Returns    : Instance name

    Example    : baya_get_bayadb_instance_name -inst instObject
                
[111] Command : baya_save_as_ipxact_design 

    Description: Saves the current verilog module or the specified module
                 as IP-XACT Design.

    Options    :
                 -xml <Design.xml>, mandatory input to specify the file 
                         name where the currently active design needs to be
                         saved as IP-XACT Design file. The specified file
                         must have .xml extension.
                 -v2014 , optional boolean switch to enable IP-XACT version is 2014

                 -module <module name>, optional input to specify the 
                                        module name to be saved as IP-XACT
                                        Design ,in absence of this switch the
                                        currently active design will be saved
    Returns    : None

    Example    : baya_save_as_ipxact_design -xml BayaConnDB.xml -module MMSS
                
[112] Command : baya_save_connection_db 

    Description: Saves the currently active connection database into the specified XML file, must have .xml extension

    Options    :
                 -xml <BayaConnDB.xml>, mandatory input to specify the file
                         name where the currently active Baya connection DB
                         will be saved.
                 -json <baya_conn.json>, switch to specify the JSON file name
                         where the currently active Baya connection DB will 
                         be saved.

    Returns    : None

    Example    : baya_save_connection_db -xml BayaConnDB.xml -json baya_conn.json
                
[113] Command : baya_get_ipxact_connections_between_two_instances 

    Description: Returns the list of IP-XACT connections between two instances
                 The returned connections gets extracted from the given
                 IP-XACT Design object. You can get the IP-XACT Design object 
                 by loading it explicity preferably along with associated 
                 IP-XACT component. In worst case, if the IP-XACT Design and
                 Component is not available but the Verilog Module is available,
                 then generate the IP-XACT Design & Compoent through the 
                 verilog2ipxact tool from EDAUtils.


    Options    :
                 -design <IP-XACT Design Object>, mandatory input to specify the
                         IP-XACT Design Object from where connections to be
                         extracted
                 -inst_1 <Instance Name>, the first instance name 
                 -inst_2 <Instance Name>, the second instance name 

    Returns    : List of the IP-XACT Connection Objects between the 

    Example    : baya_get_ipxact_connections_between_two_instances
                
[114] Command : baya_get_ipxact_connections_between_instance_and_top 

    Description: Returns the list of IP-XACT connections between an instance
                 and the top design.  

    Options    :
                 -design <IP-XACT Design Object>, mandatory input to specify the
                         IP-XACT Design Object from where connections to be
                         extracted
                 -inst <Instance Name>, the instance name 

    Returns    : List of the IP-XACT Connection Objects

    Example    : baya_get_ipxact_connections_between_instance_and_top
                
[115] Command : baya_import_connectivity_from_modular_csv_dir_and_partition 

    Description: Reads the specified Baya connectivity from modular CSV file and
                 updates those as per the par the partition defintion( JSON ).
                 Creates new CSV corresponding to the connectivity of the partitions.
         Then imports those updated/additional CSV files to create partitions
         and connect those. 

    Options    : 
                 -top <top-name>, Top module name i.e name of the SOC/SubSystem module

                 -dirs <dr1:dir2> Colon separated directories containing CSV files for each module instance.
              The CSV file would be like <inst name>.<module name>.csv .
              If the <inst name> is not provided i.e. the CSV file name is
              like <module name>.csv then the instance name will be created
              as u_<module name> . YOu just need to provide connectivity
              of the input pins of the module for which CSV is given.

                 -par <par.json> JSON file containing partition definition 

                 -outdir <outcsv> optional, directory where updated/additional CSV to be written
          
                 -outtcl <output.tcl> , optional switch, the output 
                          Tcl file name which to be created by translating
                          the CSV files inside the input CSV directory.

    Example    : baya_import_connectivity_from_modular_csv_dir_and_partition -top mytop -dirs csv1:csv2 -par par.json -outdir csvpar -outtcl output.tcl
                
[116] Command : baya_import_connectivity_from_modular_csv_dir 

    Description: Reads the specified Baya connectivity from modular CSV file and
                 creates corresponding Baya Tcl commands and the same gets
                 executed to establish the connections. Expectation is that for each
         instance, the INPUT port's connectivity is provided along with parameter 
         override as needed.

    Options    : 
                 -dirs <dir1:dir2>,Colon separated directories containing CSV files for each module instance.
              The CSV file would be like <inst name>.<module name>.csv .
              If the <inst name> is not provided i.e. the CSV file name is
              like <module name>.csv then the instance name will be created
              as u_<module name> . YOu just need to provide connectivity
              of the input pins of the module for which CSV is given.

                 -csvfiles <mod1.csv:dir/mod2.csv>, To provide CSV modular files containing connectivity details.
                   You must specify CSV files either through the -csvfiles or
               through the -dirs switch
                   
                 -outtcl <output.tcl> , optional switch, the output 
                          Tcl file name which to be created by translating
                          the CSV files inside the input CSV directory.

    Example    : baya_import_connectivity_from_modular_csv_dir -dirs csv1:csv2 -csvfiles foo.csv:bar.csv -outtcl output.tcl
                
[117] Command : baya_import_connectivity_csv 

    Description: Reads the specified Baya connectivity CSV/XLS/XLSX file and
                 creates corresponding Baya Tcl commands and the same gets
                 executed to establish the connections.

    Options    : 
                 -file <connections.csv|connections.xls|connections.xlsx> ,
                          mandatory input, Baya connectivity CSV/XLS/XLSX file,
                          see the template in the bin directory 

                 -outtcl <connections.out.tcl> , optional switch, the output 
                          Tcl file name which to be created by translating
                          the input CSV/XLS/XLSX file
    Example    : baya_import_connectivity_csv -file connections.csv -outtcl conn.tcl
                
[118] Command : baya_generate_connectivity_db_from_csv 

    Description: Reads the specified Baya connectivity CSV/XLS/XLSX file and
                 creates corresponding Baya Connection DB XML file which can
                 reused further and queried to extract information.

    Options    : 
                 -file <connections.csv|connections.xls|connections.xlsx> ,
                          mandatory input, Baya connectivity CSV/XLS/XLSX file,
                          see the template in the bin directory 

                 -outxml <BayaConnections.xml> , switch to specify the output 
                          connectivity databse XML file name 
    Example    : baya_generate_connectivity_db_from_csv -file connections.csv -outxml BayaConnectionDB.xml
                
[119] Command : baya_generate_fv_connectivity_check_csv 

    Description: Generates connectivity check CSV for formal verification
                 tools viz VC-Formal or JasperGold. This command can be
                 used after inserting all the connections or after reading
                 the connectivity CSV files. 
    Options    : 
                 -tool <vcf|jg> , switch to specify  formal tool name.
                          Provide value 'vcf' if you want to generate VC-Formal
                          CC check CSV. For the Jasper connectivity, provide 'jg'.

                 -csv <conn.csv> , switch to specify the output connectivity CSV file name.
                          
    Example    : baya_generate_fv_connectivity_check_csv -tool jg -csv conn.jg.csv
                
[120] Command : set_root 

    Description: Sets the specified module name as the root module 
    Options    : 
                 <module name> , mandatory argument to specify the module name as root module
    Example    : set_root topMod
                
[121] Command : ls 

    Description: lists down all the objects
    Options    : 
                 -p , optional boolean switch to enable the port listing
                 -n , optional boolean switch to enable the net listing
                 -i , optional boolean switch to enable the instance listing
                 -h , optional boolean switch to enable hierarchical objects
                 <pattern> , optional inout to specify the pattern to be matched

    Example    : ls -i -h /top/inst1/inst* 
                
[122] Command : cd 

    Description: changes current working module to the specified hierarchical path 
    Options    : 
                 <hierarchical instance name> , mandatory argument to specify the hierarchical instance path. 
    Example    : cd /top/inst1/inst2 
                
[123] Command : mkdir 

    Description: creates the specified hierarchical instance corresponding to the specified module 
    Options    : 
                 <hierarchical instance name> , mandatory argument to specify the hierarchical instance  to be created. 
                 -m <module name> , mandatory input, the name of the module which is to be instantiated
    Example    : mkdir /top/inst1/inst2 -m mod1
                
[124] Command : pwd 

    Description: returns the hierarchical instance path which is being considered as current working module.
               
[125] Command : rm 

    Description: removes the specified hierarchical instance from the design database
    Options    : 
                 <hierarchical instance name> , mandatory argument to specify the hierarchical instance  to be deleted. 
    Example    : rm /top/inst1/inst2 
                
[126] Command : rename 

    Description: renames the specified object to the given name
    Options    : 
                 <current name> , mandatory argument to specify the current name which needs to be renamed
                 <new name> , mandatory argument to specify the new name 
    Example    : rename /top/inst1/inst2 /top/inst1/newInst
                

