
Objectives: Demonstrate ECO capabilities with Baya, covers below scenarios
    1. Remove an instance from the top module
    2. Add an instance of a new module & specify connectivity of that new instance
    3. Add a new port in the top and connnect that with an instance
    4. Remove an existing port map
    5. Tie low in some bits in a pin
    6. Insert glue logic

Howto run ?
    baya-shell -f example.tcl

